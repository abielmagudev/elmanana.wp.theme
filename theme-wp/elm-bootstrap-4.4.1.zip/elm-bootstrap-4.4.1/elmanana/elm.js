$(function () {
    $('[data-toggle="tooltip"]').tooltip();
    $('.carousel').carousel();

    $('#toggleAlertUltimasNoticias').on('click', function (e) {
        e.preventDefault();
        $('#alertUltimasNoticias').slideToggle();
    });

    $('#navigationModal').on('show.bs.modal hide.bs.modal', function(e) {
        $('#toggleNavigationModal > i').toggleClass('fa-times');
    });

    $('#mas-tabs li:last-child a').tab('show');
});
